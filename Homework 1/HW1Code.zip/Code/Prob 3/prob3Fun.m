function f = prob3Fun(x,a,b,s)

f = x - a +b*sinh(x-cos(s-1));

end