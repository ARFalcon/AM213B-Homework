function f = prob4Fun(u,t)
l = 10^6;
f = -l*sinh(u-cos(t-1));

end