function f = prob6Fun(u)

    f = -u;

end